(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_react-icons_hi2_index_mjs_d1d12524._.js",
  "static/chunks/node_modules_react-icons_lib_74ccc930._.js",
  "static/chunks/node_modules_next_navigation_ff30cc2f.js",
  "static/chunks/src_app_f23f5267._.js"
],
    source: "dynamic"
});
