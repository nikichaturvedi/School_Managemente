(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_3c035b92._.js",
  "static/chunks/src_app_components_b83af698._.js",
  "static/chunks/node_modules_slick-carousel_slick_2cb6f297._.css"
],
    source: "dynamic"
});
