(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/app/components/Home-Cards.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>HomeCards)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function HomeCards() {
    _s();
    const cards = [
        {
            image: '/card1.jpg',
            title: 'EARLY EDUCATION',
            description: 'Early Childhood and Pre-Kindergarten',
            longDescription: 'The Early Education program emphasizes hands-on learning experiences, building the foundation for future academic success. Our dedicated teachers work closely with each child to create an inclusive and nurturing environment.',
            bgColor: 'bg-[#279989]'
        },
        {
            image: '/card2.jpg',
            title: 'LOWER SCHOOL',
            description: 'Grades Kindergarten to 8',
            longDescription: 'The Lower School program focuses on academic growth while also encouraging leadership, respect, and social responsibility. Students engage in a variety of subjects that build a strong academic foundation.',
            bgColor: 'bg-yellow-500'
        },
        {
            image: '/card3.jpg',
            title: 'UPPER SCHOOL',
            description: 'Grades 8 to 12',
            longDescription: 'Our Upper School provides a rigorous academic environment and offers numerous extracurricular opportunities. Students are prepared for college through specialized guidance and personalized learning experiences.',
            bgColor: 'bg-[#44883E]'
        }
    ];
    const [activeCard, setActiveCard] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isMobile, setIsMobile] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HomeCards.useEffect": ()=>{
            const handleResize = {
                "HomeCards.useEffect.handleResize": ()=>{
                    setIsMobile(window.innerWidth < 768);
                }
            }["HomeCards.useEffect.handleResize"];
            handleResize();
            window.addEventListener('resize', handleResize);
            return ({
                "HomeCards.useEffect": ()=>window.removeEventListener('resize', handleResize)
            })["HomeCards.useEffect"];
        }
    }["HomeCards.useEffect"], []);
    const handleToggle = (index)=>{
        if (isMobile) {
            setActiveCard((prev)=>prev === index ? null : index);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: " py-6 md:py-12  bg-white",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-7xl mx-auto px-4 sm:px-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-center  mb-8 px-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-3xl font-bold text-[#425780] pt-2 mb-4 leading-tight",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "relative inline-block",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "relative z-10",
                                        children: "The SevenUnique School"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/Home-Cards.jsx",
                                        lineNumber: 59,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "absolute bottom-0 left-0 w-full h-2 bg-[#a3dfd7] -rotate-1 -z-0"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/components/Home-Cards.jsx",
                                        lineNumber: 60,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/components/Home-Cards.jsx",
                                lineNumber: 58,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/Home-Cards.jsx",
                            lineNumber: 57,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-lg text-gray-600 max-w-3xl mx-auto",
                            children: "One of the best private day schools in Jaipur, offering exceptional education from early childhood through eighth grade."
                        }, void 0, false, {
                            fileName: "[project]/src/app/components/Home-Cards.jsx",
                            lineNumber: 64,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/components/Home-Cards.jsx",
                    lineNumber: 56,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-1 md:grid-cols-3 gap-6",
                    children: cards.map((card, index)=>{
                        const isActive = activeCard === index;
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            onClick: ()=>handleToggle(index),
                            className: `group relative rounded-xl overflow-hidden transition-all duration-300 cursor-pointer
                  ${card.bgColor} text-white
                  ${isActive ? 'md:scale-100 scale-[1.02] z-10 shadow-lg' : ''}
                  ${!isMobile ? 'hover:scale-[1.02] hover:shadow-lg' : ''}
                  h-full flex flex-col
                `,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-1 flex flex-col p-6",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: `flex flex-col items-center text-center transition-all ${isMobile && isActive ? 'hidden' : 'block'} ${!isMobile ? 'md:group-hover:hidden' : ''}`,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "relative w-32 h-32 mb-3 rounded-full border-4 border-white border-opacity-50 overflow-hidden",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        src: card.image,
                                                        alt: card.title,
                                                        fill: true,
                                                        className: "object-cover",
                                                        sizes: "(max-width: 768px) 100vw, 200px",
                                                        priority: true
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/components/Home-Cards.jsx",
                                                        lineNumber: 89,
                                                        columnNumber: 23
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/Home-Cards.jsx",
                                                    lineNumber: 88,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-xl font-bold mb-2",
                                                    children: card.title
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/Home-Cards.jsx",
                                                    lineNumber: 98,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-white text-opacity-90",
                                                    children: card.description
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/Home-Cards.jsx",
                                                    lineNumber: 99,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/components/Home-Cards.jsx",
                                            lineNumber: 87,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: `flex-1 flex flex-col justify-center transition-all ${isMobile ? isActive ? 'block' : 'hidden' : 'hidden md:group-hover:flex'}`,
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-xl font-bold mb-3 text-center",
                                                    children: card.title
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/Home-Cards.jsx",
                                                    lineNumber: 104,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-white text-opacity-90 mb-4 text-center",
                                                    children: card.longDescription
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/Home-Cards.jsx",
                                                    lineNumber: 105,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex justify-center",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "inline-block px-4 py-2 bg-white bg-opacity-20 rounded-lg text-sm font-medium",
                                                        children: "Learn More"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/components/Home-Cards.jsx",
                                                        lineNumber: 107,
                                                        columnNumber: 23
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/Home-Cards.jsx",
                                                    lineNumber: 106,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/components/Home-Cards.jsx",
                                            lineNumber: 103,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/components/Home-Cards.jsx",
                                    lineNumber: 85,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute bottom-0 left-0 right-0 h-1 bg-white bg-opacity-30"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/Home-Cards.jsx",
                                    lineNumber: 115,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute top-4 right-4 w-3 h-3 rounded-full bg-white bg-opacity-50"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/components/Home-Cards.jsx",
                                    lineNumber: 116,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, index, true, {
                            fileName: "[project]/src/app/components/Home-Cards.jsx",
                            lineNumber: 74,
                            columnNumber: 15
                        }, this);
                    })
                }, void 0, false, {
                    fileName: "[project]/src/app/components/Home-Cards.jsx",
                    lineNumber: 69,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/components/Home-Cards.jsx",
            lineNumber: 54,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/components/Home-Cards.jsx",
        lineNumber: 53,
        columnNumber: 5
    }, this);
}
_s(HomeCards, "uJ7iBpQMq4NiIDRi+R3RCmERfPU=");
_c = HomeCards;
var _c;
__turbopack_context__.k.register(_c, "HomeCards");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/components/Facultys.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Faculty)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fa/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$slick$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-slick/lib/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function Faculty() {
    _s();
    const facultyMembers = [
        {
            name: 'Dr. Alice Green',
            position: 'Principal',
            bio: 'Dr. Alice Green brings over 15 years of educational leadership experience,  diverse, and equitable learning environments. Throughout her career, she has been dedicated to building strong relationships between students, parents, and faculty members, ensuring that every student has access to the tools and resources needed to thrive academically. She has worked in both public and private institutions, and her expertise lies in educational management, curriculum development, and policy creation. Dr. Green is also a published author on the subjects of educational reform and leadership development.',
            email: 'alice.green@school.edu',
            phone: '(123) 456-7890',
            image: '/faculty1.jpg',
            degree: 'PhD in Education',
            subjects: [
                'Educational Leadership',
                'Student Affairs'
            ],
            officeHours: 'Mon-Fri: 9 AM - 5 PM'
        },
        {
            name: 'Mr. John Smith',
            position: 'Math Teacher',
            bio: 'Mr. John Smith is a passionate educator with over 12 years of teaching experience in mathematics. He has a deep love for making math accessible and exciting for students of all levels, whether they are struggling to understand basic concepts or are tackling advanced calculus. John uses interactive and hands-on learning techniques to engage his students, including real-world applications that help them see how math is integral to their daily lives. His teaching philosophy is built around the belief that all students can succeed in math with the right support, and he strives to create a classroom environment that fosters curiosity and confidence.',
            email: 'john.smith@school.edu',
            phone: '(123) 456-7891',
            image: '/faculty2.jpg',
            degree: 'MSc in Mathematics',
            subjects: [
                'Algebra',
                'Calculus',
                'Geometry'
            ],
            officeHours: 'Mon, Wed: 2 PM - 4 PM'
        },
        {
            name: 'Ms. Maria Lopez',
            position: 'English Teacher',
            bio: 'Ms. Maria Lopez has been an English teacher for over 10 years, specializing in literature, creative writing, and grammar. She has a unique ability to inspire students to engage with literature on a deeper level, encouraging them to analyze texts from different perspectives and relate them to their own lives. Maria believes that reading and writing are fundamental tools for personal expression, and she fosters a classroom environment where students feel safe to share their thoughts and ideas. Her teaching approach combines traditional literary analysis with creative assignments that help students find their voice and improve their writing skills.',
            email: 'maria.lopez@school.edu',
            phone: '(123) 456-7892',
            image: '/faculty3.jpg',
            degree: 'MA in English Literature',
            subjects: [
                'Literature',
                'Creative Writing',
                'Grammar'
            ],
            officeHours: 'Tue, Thu: 11 AM - 1 PM'
        },
        {
            name: 'Dr. David Clark',
            position: 'Science Teacher',
            bio: 'Dr. David Clark is a dedicated science teacher with a deep passion for  learners. With a background in physics, chemistry, each subject with an enthusiasm that is contagious. He encourages students to explore the world around them through hands-on experiments, critical thinking, and problem-solving exercises. David’s goal is to provide his students with the tools they need to not only understand scientific concepts but to think like scientists—asking questions, experimenting, and learning from their mistakes. He believes that science should be fun, engaging, and accessible to everyone, regardless of their background or prior knowledge.',
            email: 'david.clark@school.edu',
            phone: '(123) 456-7893',
            image: '/faculty4.jpg',
            degree: 'PhD in Physics',
            subjects: [
                'Physics',
                'Chemistry',
                'Environmental Science'
            ],
            officeHours: 'Mon, Fri: 10 AM - 12 PM'
        },
        {
            name: 'Ms. Emma Williams',
            position: 'History Teacher',
            bio: 'Ms. Emma Williams has always been fascinated by history’s ability to tell the story of humanity’s progress, mistakes, and triumphs. She teaches hist dates and facts, but truly understanding the forces that have shaped societies throughout the world. Emma incorporates various teaching methods, including project-based learning, interactive discussions, and historical simulations, to help students better understand the past and how it connects to current events. Her classroom is a space where students are encouraged to think critically about historical narratives and develop their own opinions on the events that shaped the world.',
            email: 'emma.williams@school.edu',
            phone: '(123) 456-7894',
            image: '/faculty5.jpg',
            degree: 'MA in History',
            subjects: [
                'World History',
                'American History'
            ],
            officeHours: 'Wed: 1 PM - 3 PM'
        },
        {
            name: 'Mr. James Lee',
            position: 'Computer Science Teacher',
            bio: 'Mr. James Lee is a computer science educator with a passion for technology and coding. With a background in both softwaremaking the world of programming students, regardless of their prior experience. In his classroom, students learn to think like programmers, tackling problems logically and creatively. James teaches various programming languages such as Python, JavaScript, and Java, and incorporates real-world projects that help students build skills for future careers in tech. He believes that technology is the future, and it is essential for young people to understand the tools that drive innovation in the modern world.',
            email: 'james.lee@school.edu',
            phone: '(123) 456-7895',
            image: '/faculty6.jpg',
            degree: 'MSc in Computer Science',
            subjects: [
                'Programming',
                'Data Structures',
                'Web Development'
            ],
            officeHours: 'Tue, Thu: 3 PM - 5 PM'
        },
        {
            name: 'Ms. Olivia Brown',
            position: 'Art Teacher',
            bio: 'Ms. Olivia Brown is a passionate artist and  her creativity into the classroom every day. With a background in fine arts and digital media, Olivia encourages her students to explore their artistic potential in a variety of mediums, from traditional painting and sculpture to digital art and graphic design. She believes that art is an essential part of self-expression and that all students have the potential to be creative. Olivia fosters a supportive environment where students feel free to experiment with their ideas and challenge themselves to think outside the box. Her goal is in their artistic abilities and discover a lifelong passion for creativity.',
            email: 'olivia.brown@school.edu',
            phone: '(123) 456-7896',
            image: '/teacher2.jpg',
            degree: 'MFA in Fine Arts',
            subjects: [
                'Painting',
                'Sculpture',
                'Digital Arts'
            ],
            officeHours: 'Mon, Thu: 10 AM - 12 PM'
        },
        {
            name: 'Mr. Liam Taylor',
            position: 'Physical Education Teacher',
            bio: 'Mr. Liam Taylor is an enthusiastic physical education teacher with a background in kinesiology and sports coaching. Liam believes that physical activity is crucial not only for a healthy body but also for a healthy mind. He encourages his students to take part in various sports, outdoor activities, and fitness challenges to improve their overall well-being. His lessons focus on building teamwork, leadership, and sportsmanship, in addition to developing physical strength and coordination. Liam’s mission is to instill a lifelong love for physical activity in his students, empowering them to lead healthy and active lives.',
            email: 'liam.taylor@school.edu',
            phone: '(123) 456-7897',
            image: '/teacher3.jpg',
            degree: 'BA in Kinesiology',
            subjects: [
                'Physical Education',
                'Sports Coaching'
            ],
            officeHours: 'Mon, Wed: 9 AM - 11 AM'
        }
    ];
    const [expandedIndex, setExpandedIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const toggleDetails = (index)=>{
        setExpandedIndex(expandedIndex === index ? null : index);
    };
    const settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 2,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 1
                }
            }
        ]
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "py-5 mb-5 md:py-16 bg-gray-50",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-7xl mx-auto px-2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-3xl sm:text-4xl px-4 sm:px-6 font-extrabold text-left text-[#4a6088] mb-6",
                    children: "Meet Our Faculty"
                }, void 0, false, {
                    fileName: "[project]/src/app/components/Facultys.jsx",
                    lineNumber: 126,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-lg text-left text-[#4a6088] px-4 sm:px-6 pb-6 sm:pb-8 md:pb-12",
                    children: "Our faculty members are experienced, dedicated, and passionate about helping students succeed."
                }, void 0, false, {
                    fileName: "[project]/src/app/components/Facultys.jsx",
                    lineNumber: 129,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$slick$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    ...settings,
                    children: facultyMembers.map((faculty, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "px-2.5 md:px-4",
                            children: [
                                " ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-white rounded-lg shadow-md overflow-hidden p-6 h-full",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-start mb-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "w-32 h-32 rounded-full overflow-hidden mr-6 flex-shrink-0",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                        src: faculty.image || '/placeholder-profile.jpg',
                                                        alt: faculty.name,
                                                        className: "object-cover w-full h-full"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/components/Facultys.jsx",
                                                        lineNumber: 139,
                                                        columnNumber: 41
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/components/Facultys.jsx",
                                                    lineNumber: 138,
                                                    columnNumber: 37
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex-1",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                            className: "text-xl font-semibold text-[#4a6088]",
                                                            children: faculty.name
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/components/Facultys.jsx",
                                                            lineNumber: 146,
                                                            columnNumber: 41
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-sm text-[#279989] font-semibold mb-2",
                                                            children: faculty.position
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/components/Facultys.jsx",
                                                            lineNumber: 147,
                                                            columnNumber: 41
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-gray-600 text-sm line-clamp-4",
                                                            children: faculty.bio
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/components/Facultys.jsx",
                                                            lineNumber: 148,
                                                            columnNumber: 41
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/components/Facultys.jsx",
                                                    lineNumber: 145,
                                                    columnNumber: 37
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/components/Facultys.jsx",
                                            lineNumber: 137,
                                            columnNumber: 33
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>toggleDetails(index),
                                                    className: "flex items-center text-[#279989] hover:text-[#3d6963] focus:outline-none",
                                                    children: [
                                                        expandedIndex === index ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaChevronUp"], {
                                                            className: "mr-2"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/components/Facultys.jsx",
                                                            lineNumber: 158,
                                                            columnNumber: 45
                                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaChevronDown"], {
                                                            className: "mr-2"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/components/Facultys.jsx",
                                                            lineNumber: 160,
                                                            columnNumber: 45
                                                        }, this),
                                                        expandedIndex === index ? 'Hide Details' : 'Show Details'
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/components/Facultys.jsx",
                                                    lineNumber: 153,
                                                    columnNumber: 37
                                                }, this),
                                                expandedIndex === index && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "mt-4 text-sm text-gray-600",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center mb-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaPhoneAlt"], {
                                                                    className: "mr-2"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/components/Facultys.jsx",
                                                                    lineNumber: 168,
                                                                    columnNumber: 49
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    children: faculty.phone
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/components/Facultys.jsx",
                                                                    lineNumber: 169,
                                                                    columnNumber: 49
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/components/Facultys.jsx",
                                                            lineNumber: 167,
                                                            columnNumber: 45
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center mb-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaEnvelope"], {
                                                                    className: "mr-2"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/components/Facultys.jsx",
                                                                    lineNumber: 172,
                                                                    columnNumber: 49
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                                    href: `mailto:${faculty.email}`,
                                                                    className: "underline",
                                                                    children: faculty.email
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/components/Facultys.jsx",
                                                                    lineNumber: 173,
                                                                    columnNumber: 49
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/components/Facultys.jsx",
                                                            lineNumber: 171,
                                                            columnNumber: 45
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                                    children: "Degree:"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/components/Facultys.jsx",
                                                                    lineNumber: 177,
                                                                    columnNumber: 48
                                                                }, this),
                                                                " ",
                                                                faculty.degree
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/components/Facultys.jsx",
                                                            lineNumber: 177,
                                                            columnNumber: 45
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                                    children: "Subjects:"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/components/Facultys.jsx",
                                                                    lineNumber: 178,
                                                                    columnNumber: 48
                                                                }, this),
                                                                " ",
                                                                faculty.subjects.join(', ')
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/components/Facultys.jsx",
                                                            lineNumber: 178,
                                                            columnNumber: 45
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                                    children: "Office Hours:"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/components/Facultys.jsx",
                                                                    lineNumber: 179,
                                                                    columnNumber: 48
                                                                }, this),
                                                                " ",
                                                                faculty.officeHours
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/components/Facultys.jsx",
                                                            lineNumber: 179,
                                                            columnNumber: 45
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/components/Facultys.jsx",
                                                    lineNumber: 166,
                                                    columnNumber: 41
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/components/Facultys.jsx",
                                            lineNumber: 152,
                                            columnNumber: 33
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/components/Facultys.jsx",
                                    lineNumber: 136,
                                    columnNumber: 29
                                }, this)
                            ]
                        }, index, true, {
                            fileName: "[project]/src/app/components/Facultys.jsx",
                            lineNumber: 135,
                            columnNumber: 25
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/src/app/components/Facultys.jsx",
                    lineNumber: 133,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/components/Facultys.jsx",
            lineNumber: 125,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/components/Facultys.jsx",
        lineNumber: 124,
        columnNumber: 9
    }, this);
}
_s(Faculty, "bzV0X/G6ETLTHnPPQQ2qIqf2BxU=");
_c = Faculty;
var _c;
__turbopack_context__.k.register(_c, "Faculty");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_app_components_52de6e3f._.js.map