(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7f5._.js",
  "static/chunks/node_modules_react-icons_lib_74ccc930._.js",
  "static/chunks/node_modules_framer-motion_dist_es_82de910d._.js",
  "static/chunks/node_modules_motion-dom_dist_es_c7a0b6ce._.js",
  "static/chunks/node_modules_next_dist_5eec24f3._.js",
  "static/chunks/node_modules_motion-utils_dist_es_7559145f._.js",
  "static/chunks/src_app_components_OnlineData_jsx_d172cdc9._.js"
],
    source: "dynamic"
});
