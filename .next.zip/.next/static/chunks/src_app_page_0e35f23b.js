(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_6bab6250._.js",
  "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7f5._.js",
  "static/chunks/node_modules_react-icons_lib_74ccc930._.js",
  "static/chunks/node_modules_react-slick_lib_4ed59f97._.js",
  "static/chunks/node_modules_4b9304af._.js",
  "static/chunks/src_app_components_ba805f8d._.js",
  "static/chunks/node_modules_slick-carousel_slick_2cb6f297._.css"
],
    source: "dynamic"
});
