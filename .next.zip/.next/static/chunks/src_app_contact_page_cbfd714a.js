(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7f5._.js",
  "static/chunks/node_modules_react-icons_lib_74ccc930._.js",
  "static/chunks/node_modules_framer-motion_dist_es_82de910d._.js",
  "static/chunks/node_modules_motion-dom_dist_es_c7a0b6ce._.js",
  "static/chunks/node_modules_5f8f4490._.js",
  "static/chunks/src_app_components_ContactPage_jsx_6c3bb1b8._.js"
],
    source: "dynamic"
});
