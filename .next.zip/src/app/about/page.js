import AboutHero from "../components/AboutHero";
import AboutData from "../components/AboutData";
export default function Home() {
    return (
        <>
            <AboutHero></AboutHero>
            <AboutData></AboutData>
        </>
    );
}
